# ALPHAQUANT V6.2 GitHub Backtest Fix

Replace **both** `signal_bot.py` and `backtest_inst.py` at repository root. Do not upload `signal_bot (7).py` without renaming.

```bash
pip install -r requirements.txt
python -m py_compile signal_bot.py backtest_inst.py
GATE_MODE=PROXY python backtest_inst.py --days 30 --out bt_out
```

The original workflow invocation `python backtest_inst.py --days "$DAYS" --end "$END" --telegram` remains supported. If `END` is blank, current UTC time is used.

This backtester uses the **actual V6.2** `gate_pipeline`, not removed V6.1 `build_signal`/`simulate_trade`. OKX downloads are independent of `signal_bot.api`. It uses 15-minute candles for exit simulation, with stop-first intrabar ordering, next-candle open entry, conservative fill assumptions, and realized-trade equity. Historical spreads, real aggressor order flow and macro inputs are not included; `STRICT` deliberately produces no signals.

**Research limitations:** next-open fills can change initial stop distance; risk sizing in the report uses fractional equity and does not simulate leverage limits, exchange minimum size, or margin liquidations. 15m OHLC cannot resolve intrabar order sequencing. The runner does not reproduce V6.2 live 5m monitoring exactly. It does not yet enforce all live kill switches or portfolio heat during historical simulation. No claims of live/backtest equivalence or validated profitability.

Data acquisition can be slow for multi-year history and subject to OKX retention/rate limits. Test 30 days before increasing `--days`.
